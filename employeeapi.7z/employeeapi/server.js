const {emailMHtml} = require("./emails/emailTemplate");
let cron = require('node-cron');
let fs = require('fs');
const nodemailer = require("nodemailer");
let obj = JSON.parse(fs.readFileSync('./db/employees.json', 'utf8'));


cron.schedule('30 2 * * *', () => {
    console.log('Happy birthday---Running a job at 02:30 am at "Africa/Johannesburg" timezone');
    sendEmail().then(res => {
        console.error('res',res)
    }).catch(err => {
        console.error(err)
    });
}, {
    scheduled: true,
    timezone: "Africa/Johannesburg"
});


cron.schedule('* * * * *', () => {
    console.log('Checking test check every minute');

    

    sendEmail().then(res => {
        console.error('res',res)
    }).catch(err => {
        console.error(err)
    });

    

}, {
    scheduled: true,
    timezone: "Africa/Johannesburg"
});


async function sendEmail() {
    for (const elements of obj) {
        const index = obj.indexOf(elements);
        if (elements.dateOfBirth) {
            if (elements.employmentEndDate === null) {// test if the user is still employyed

                const date = elements.dateOfBirth.split('T')[0];
                const month = date.split('-')[2]
                const day = date.split('-')[1]
                // console.log(date, ':::', day, month)

                const yourDate = new Date()
                const today = yourDate.toISOString().split('T')[0];
                const todayMonth = today.split('-')[1];
                const todayDay = today.split('-')[2];
                // console.log(today, '||||', todayDay, todayMonth);
                if (todayDay === day && todayMonth === month) { // test if the birthday is today
                    console.log("happy birth day")
                    const messageHtml = emailMHtml(elements.name + " " + elements.lastname);
                        // lets send the email now
                    const message = {
                        from: "144morlac@gmail.com",
                        to: elements.email,
                        subject: "Birthday message",
                        text: "",
                        html: messageHtml
                    };


                    const smtp = nodemailer.createTransport({
                        host: 'smtp.gmail.com',
                        service: 'gmail',
                        port: 587,

                        tls: {
                            rejectUnauthorized: false
                        },
                        auth: {
                            user: '144morlac@gmail.com',
                            pass: 'Hello@003',
                        },
                    });
                    await smtp.sendMail(message);
                }
            }
        }


    }
}