const {emailMHtml} = require("./emails/emailTemplate");
let cron = require('node-cron');
let fs = require('fs');
 const nodemailer = require("nodemailer");
// import * as nodemailer from 'nodemailer';
let obj = JSON.parse(fs.readFileSync('employees.json', 'utf8'));


cron.schedule('30 2 * * *', () => {
    console.log('Happy birthday---Running a job at 02:30 am at "Africa/Johannesburg" timezone');
    sendEmail().then(res => {
        console.error('res',res)
    }).catch(err => {
        console.error(err)
    });
}, {
    scheduled: true,
    timezone: "Africa/Johannesburg"
});
cron.schedule('* * * * *', async () => {
    console.log('Checking test check every minute');
    await sendEmail();

}, {
    scheduled: true,
    timezone: "Africa/Johannesburg"
});


async function sendEmail() {
    for (const elements of obj) {

        if (elements.dateOfBirth) {
            if (elements.employmentEndDate === null) {// test if the user is still employyed

                const date = elements.dateOfBirth.split('T')[0];
                const month = date.split('-')[2]
                const day = date.split('-')[1]
               //  console.log(date, ':::', day, month)

                const yourDate = new Date()
                const today = yourDate.toISOString().split('T')[0];
                const todayMonth = today.split('-')[2];
                const todayDay = today.split('-')[1];
                // console.log(today, '||||', todayDay, todayMonth);
                if (todayDay === day && todayMonth === month) { // test if the birthday is today
                    console.log("happy birth day")
                    const messageHtml = emailMHtml(elements.name + " " + elements.lastname);
                   // console.log("eeee")
                    const transporter = nodemailer.createTransport({
                        service: 'gmail',
                        auth: {
                            user: '144morlac@gmail.com',
                            pass: 'Hello@003',
                        }
                    });

                    const mailOptions = {
                        from: "144moe@gmail.com",
                        to:elements.email,
                        subject: "Birthday message",
                        html: messageHtml
                    };

                   await transporter.sendMail(mailOptions)

                }
            }
        }


    }
}