# EmployeeApi
// Steps to get the code runing

Clone
command 'npm i'  //via terminal
command 'npm run start' //to start the server
